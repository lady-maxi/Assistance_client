const axios = require('axios');

const EVENT_SERVICE_URL = process.env.NODE_ENV === 'production' 
  ? 'http://event-service:8080/api/events'
  : 'http://localhost:8080/api/events';

// Get all events
const getAllEvents = async () => {
  try {
    const response = await axios.get(`${EVENT_SERVICE_URL}`);
    return response.data;
  } catch (error) {
    console.error('Error fetching events:', error.message);
    throw new Error('Failed to fetch events');
  }
};

// Get an event by ID
const getEventById = async (eventId) => {
  try {
    const response = await axios.get(`${EVENT_SERVICE_URL}/${eventId}`);
    return response.data;
  } catch (error) {
    console.error(`Error fetching event with ID ${eventId}:`, error.message);
    if (error.response && error.response.status === 404) {
      throw new Error(`Event with ID ${eventId} not found`);
    }
    throw new Error('Failed to fetch event');
  }
};

// TODO-REST2: Implémentez la méthode bookEventSeats pour effectuer un appel REST
// Cette méthode doit envoyer une requête POST au service Événements pour réserver des places
// Elle doit gérer les erreurs appropriées et retourner la réponse du service Événements
const bookEventSeats = async (eventId, seats) => {
  try {
    const response = await axios.post(`${EVENT_SERVICE_URL}/${eventId}/book`, {
      seats: seats
    });

    return response.data;
  } catch (error) {
    console.error(`Error booking seats for event ${eventId}:`, error.message);
    if (error.response) {
      throw new Error(error.response.data.error || 'Failed to book seats');
    }
    throw new Error('Failed to book seats');
  }
};

module.exports = {
  getAllEvents,
  getEventById,
  bookEventSeats
};
