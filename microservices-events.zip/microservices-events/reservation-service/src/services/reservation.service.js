const Reservation = require('../models/reservation.model');
const eventService = require('./event.service');
const rabbitmq = require('../config/rabbitmq.config');
const { publishMessage, ROUTING_KEY } = require('../config/rabbitmq.config');



// Create a new reservation with REST communication and messaging
const createReservation = async (reservationData) => {
  // Validation des données
  if (!reservationData.eventId || !reservationData.userId || 
      !reservationData.userName || !reservationData.userEmail || 
      !reservationData.seats) {
    throw new Error('Tous les champs sont obligatoires');
  }

  if (isNaN(reservationData.eventId)) {
    throw new Error('eventId doit être un nombre');
  }

  if (isNaN(reservationData.seats)) {
    throw new Error('seats doit être un nombre');
  }

  try {
    // Vérification de l'événement
    const event = await eventService.getEventById(reservationData.eventId);
    if (!event) {
      throw new Error('Événement non trouvé');
    }

    // Vérification des places disponibles
    if (event.availableSeats < reservationData.seats) {
      throw new Error('Pas assez de places disponibles');
    }

    // Création de la réservation
    const reservation = new Reservation({
      eventId: Number(reservationData.eventId),
      userId: reservationData.userId,
      userName: reservationData.userName,
      userEmail: reservationData.userEmail,
      seats: Number(reservationData.seats)
    });

    await reservation.save();

    // Envoi du message RabbitMQ
    await rabbitmq.publishMessage(rabbitmq.ROUTING_KEY, {
      eventId: reservation.eventId,
      reservationId: reservation._id,
      userId: reservation.userId,
      seats: reservation.seats,
      status: reservation.status
    });

    return reservation;

  } catch (error) {
    console.error('Erreur création réservation:', error);
    throw new Error(`Échec de la réservation: ${error.message}`);
  }
};

// Get all reservations
const getAllReservations = async () => {
  try {
    const reservations = await Reservation.find().sort({ createdAt: -1 });
    return reservations;
  } catch (error) {
    throw new Error('Failed to fetch reservations');
  }
};

// Get reservations by user ID
const getReservationsByUserId = async (userId) => {
  try {
    const reservations = await Reservation.find({ userId }).sort({ createdAt: -1 });
    return reservations;
  } catch (error) {
    throw new Error(`Failed to fetch reservations for user ${userId}`);
  }
};

// Get a reservation by ID
const getReservationById = async (id) => {
  try {
    const reservation = await Reservation.findById(id);
    if (!reservation) {
      throw new Error(`Reservation with ID ${id} not found`);
    }
    return reservation;
  } catch (error) {
    throw new Error(error.message || `Failed to fetch reservation with ID ${id}`);
  }
};

// Cancel a reservation
const cancelReservation = async (id) => {
  try {
    const reservation = await Reservation.findById(id);
    if (!reservation) {
      throw new Error(`Reservation with ID ${id} not found`);
    }
    
    reservation.status = 'cancelled';
    await reservation.save();
    
    // Here we could also implement logic to free up seats in the event service
    
    return {
      reservation,
      message: 'Reservation cancelled successfully'
    };
  } catch (error) {
    throw new Error(error.message || `Failed to cancel reservation with ID ${id}`);
  }
};



module.exports = {
  createReservation,
  getAllReservations,
  getReservationsByUserId,
  getReservationById,
  cancelReservation
};
