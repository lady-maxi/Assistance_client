const amqp = require('amqplib');

const RABBITMQ_URL = process.env.NODE_ENV === 'production'
  ? 'amqp://guest:guest@rabbitmq:5672'
  : 'amqp://guest:guest@localhost:5672';

const EXCHANGE_NAME = 'events_exchange';
const QUEUE_NAME = 'reservation_events';
const ROUTING_KEY = 'reservation.created';

let channel = null;

// Connect to RabbitMQ and create a channel
const connect = async () => {
  try {
    const connection = await amqp.connect(RABBITMQ_URL);
    
    // Create a channel
    const ch = await connection.createChannel();
    
    // Declare an exchange
    await ch.assertExchange(EXCHANGE_NAME, 'topic', { durable: true });
    
    // Declare a queue
    await ch.assertQueue(QUEUE_NAME, { durable: true });
    
    // Bind the queue to the exchange with routing key
    await ch.bindQueue(QUEUE_NAME, EXCHANGE_NAME, 'reservation.*');
    
    channel = ch;
    console.log('Connected to RabbitMQ');
    
    // Handle connection closure
    connection.on('close', () => {
      console.log('RabbitMQ connection closed, attempting to reconnect...');
      setTimeout(connect, 5000);
    });
    
    return ch;
  } catch (error) {
    console.error('Error connecting to RabbitMQ:', error.message);
    console.log('Retrying connection in 5 seconds...');
    setTimeout(connect, 5000);
  }
};

// Initialize the connection
connect();

// TODO-MQ1: Implémentez la fonction pour publier un message à l'exchange
// Cette fonction doit vérifier si le canal est disponible, reconnecter si nécessaire,
// puis publier le message à l'exchange avec la routing key fournie
const publishMessage = async (routingKey, message) => {
try {
if (!channel) {
console.log('Channel not available, reconnecting...');
await connect();
}
channel.publish(
EXCHANGE_NAME,
routingKey,
Buffer.from(JSON.stringify(message)),
{ persistent: true }
);
console.log('Message published to exchange ${EXCHANGE_NAME} with routing key ${routingKey}');
return true;
} catch (error) {
console.error('Error publishing message to RabbitMQ:', error.message);
return false;
}
};

module.exports = {
  connect,
  publishMessage,
  EXCHANGE_NAME,
  QUEUE_NAME,
  ROUTING_KEY
};
