const amqp = require('amqplib');

let connection;
let channel;
const ROUTING_KEY = 'reservations.created';

async function initRabbitMQ() {
  try {
    connection = await amqp.connect('amqp://rabbitmq');
    channel = await connection.createChannel();
    
    await channel.assertExchange('reservations', 'topic', { durable: true });
    console.log('RabbitMQ connection established');
  } catch (error) {
    console.error('RabbitMQ connection failed:', error);
    throw error;
  }
}

async function publishMessage(routingKey, message) {
  if (!channel) {
    throw new Error('RabbitMQ channel not initialized');
  }
  
  try {
    await channel.publish(
      'reservations',
      routingKey,
      Buffer.from(JSON.stringify(message)),
      { persistent: true }
    );
    console.log('Message published:', message);
  } catch (error) {
    console.error('Failed to publish message:', error);
    throw error;
  }
}

module.exports = {
  initRabbitMQ,
  publishMessage,
  ROUTING_KEY
};