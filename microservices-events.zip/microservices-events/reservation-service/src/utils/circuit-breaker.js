class CircuitBreaker {
  constructor(options = {}) {
    this.failureThreshold = options.failureThreshold || 3;
    this.resetTimeout = options.resetTimeout || 30000; // 30 seconds
    this.failureCount = 0;
    this.isOpen = false;
    this.lastFailureTime = null;
  }

  // TODO-RESILIENCE2: Implémentez la méthode execute du circuit breaker
  // Cette méthode doit vérifier l'état du circuit avant d'exécuter la fonction
  // Si le circuit est ouvert, elle doit vérifier si le temps de reset est écoulé
  // Elle doit exécuter la fonction si le circuit est fermé ou semi-ouvert
  // Elle doit mettre à jour l'état du circuit en fonction du résultat
  async execute(fn) {
    // À implémenter
  }

  onSuccess() {
    this.failureCount = 0;
    this.isOpen = false;
  }

  onFailure() {
    this.failureCount += 1;
    this.lastFailureTime = Date.now();
    
    if (this.failureCount >= this.failureThreshold) {
      this.isOpen = true;
      console.log(`Circuit opened after ${this.failureCount} failures`);
    }
  }
}

module.exports = CircuitBreaker;
