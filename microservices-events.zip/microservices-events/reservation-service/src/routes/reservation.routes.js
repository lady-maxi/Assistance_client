const express = require('express');
const router = express.Router();
const reservationController = require('../controllers/reservation.controller');

router.post('/', reservationController.createReservation);
router.get('/', reservationController.getAllReservations);
router.get('/user/:userId', reservationController.getReservationsByUserId);
router.get('/:id', reservationController.getReservationById);
router.delete('/:id', reservationController.cancelReservation);
router.get('/events', reservationController.getAllEvents);
router.get('/events/:id', reservationController.getEventById);

module.exports = router;