const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const morgan = require('morgan');
const amqp = require('amqplib');
const { initRabbitMQ } = require('./config/rabbitmq.config');
require('dotenv').config();

const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json({
  limit: '10mb',
  verify: (req, res, buf) => {
    try {
      req.rawBody = buf.toString();
      console.log('[Reservation] Raw body received:', req.rawBody);
      req.body = JSON.parse(req.rawBody); // Validation manuelle
    } catch (e) {
      console.error('[Reservation] Invalid JSON:', {
        rawBody: req.rawBody,
        error: e.message
      });
      throw new Error('Invalid JSON format');
    }
  }
}));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(morgan('dev'));

// Middleware de logging avancé
app.use((req, res, next) => {
  console.log(`[Reservation] ${req.method} ${req.url}`);
  console.log('Headers:', req.headers);
  if (req.rawBody) {
    console.log('Body size:', Buffer.byteLength(req.rawBody), 'bytes');
  }
  next();
});

// Routes
const reservationRoutes = require('./routes/reservation.routes');
app.use('/api/reservations', reservationRoutes);
app.use('/api/events', require('./routes/event.routes'));

// Health check
app.get('/health', (req, res) => res.json({ 
  status: 'OK',
  timestamp: new Date().toISOString()
}));

// Connexion à RabbitMQ (avec réessais)
const connectRabbitMQ = async (retries = 5, interval = 5000) => {
  try {
    const conn = await amqp.connect('amqp://rabbitmq');
    console.log('[Reservation] RabbitMQ connected');
    return conn;
  } catch (err) {
    if (retries > 0) {
      console.warn(`[Reservation] RabbitMQ connection failed, retrying... (${retries} left)`);
      await new Promise(resolve => setTimeout(resolve, interval));
      return connectRabbitMQ(retries - 1, interval);
    }
    throw new Error('Failed to connect to RabbitMQ');
  }
};

// Connexion à MongoDB (avec réessais)
const connectMongoDB = async (retries = 5, interval = 5000) => {
  try {
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://mongo:27017/reservations', {
      serverSelectionTimeoutMS: 5000,
      socketTimeoutMS: 45000
    });
    console.log('[Reservation] MongoDB connected');
  } catch (err) {
    if (retries > 0) {
      console.warn(`[Reservation] MongoDB connection failed, retrying... (${retries} left)`);
      await new Promise(resolve => setTimeout(resolve, interval));
      return connectMongoDB(retries - 1, interval);
    }
    throw new Error('Failed to connect to MongoDB');
  }
};

// Gestion des erreurs
app.use((err, req, res, next) => {
  console.error('[Reservation] Error:', err.stack);
  res.status(500).json({
    error: 'Internal Server Error',
    message: err.message,
    timestamp: new Date().toISOString()
  });
});

// Gestion des exceptions non capturées
process.on('uncaughtException', (err) => {
  console.error('[Reservation] UNCAUGHT EXCEPTION!', err);
  process.exit(1);
});

process.on('unhandledRejection', (err) => {
  console.error('[Reservation] UNHANDLED REJECTION!', err);
});

// Initialisation du serveur
async function startServer() {
  try {
    await initRabbitMQ();
    await mongoose.connect(/* ... */);
    await connectRabbitMQ();
    
    const server = app.listen(port, () => {
      console.log(`[Reservation] Service running on port ${port}`);
    });
    
    // Optimisation des timeouts
    server.keepAliveTimeout = 60000;
    server.headersTimeout = 65000;
    
  } catch (error) {
    console.error('[Reservation] Failed to start server:', error);
    process.exit(1);
  }
}

startServer();

module.exports = app;