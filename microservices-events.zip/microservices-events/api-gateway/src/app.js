const express = require('express');
const morgan = require('morgan');
const cors = require('cors');
const { createProxyMiddleware } = require('http-proxy-middleware');

const app = express();
const PORT = process.env.PORT || 8000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

// Service endpoints (for production environment)
const EVENTS_SERVICE = process.env.NODE_ENV === 'production' 
  ? 'http://event-service:8080' 
  : 'http://localhost:8080';

const RESERVATIONS_SERVICE = process.env.NODE_ENV === 'production' 
  ? 'http://reservation-service:3000' 
  : 'http://localhost:3000';

const NOTIFICATIONS_SERVICE = process.env.NODE_ENV === 'production' 
  ? 'http://notification-service:5000' 
  : 'http://localhost:5000';

// Welcome route
app.get('/', (req, res) => {
  res.json({
    message: 'Welcome to the Event Booking API Gateway',
    services: {
      events: '/api/events',
      reservations: '/api/reservations',
      notifications: '/api/notifications'
    }
  });
});

// TODO-GW1: Créez le middleware de proxy pour le service événements
// Utilisez createProxyMiddleware pour router les requêtes vers le service événements
// À implémenter
// Proxy middleware for events service
app.use('/api/events', createProxyMiddleware({
target: EVENTS_SERVICE,
changeOrigin: true,
pathRewrite: {
'^/api/events': '/api/events' // Keep the same path
},
logLevel: 'debug'
}));
// TODO-GW2: Créez le middleware de proxy pour le service réservations
// Utilisez createProxyMiddleware pour router les requêtes vers le service réservations
// À implémenter

// Proxy middleware for reservations service
app.use('/api/reservations', createProxyMiddleware({
target: RESERVATIONS_SERVICE,
changeOrigin: true,
pathRewrite: {
'^/api/reservations': '/api/reservations' // Keep the same path
},
logLevel: 'debug'
}));
// TODO-GW3: Créez le middleware de proxy pour le service notifications
// Utilisez createProxyMiddleware pour router les requêtes vers le service notifications
// À implémenter

// Proxy middleware for notifications service
app.use('/api/notifications', createProxyMiddleware({
target: NOTIFICATIONS_SERVICE,
changeOrigin: true,
pathRewrite: {
'^/api/notifications': '/api/notifications' // Keep the same path
},
logLevel: 'debug'
}));
// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    error: 'Internal Server Error',
    message: err.message
  });
});

// Start the server
app.listen(PORT, () => {
  console.log(`API Gateway running on port ${PORT}`);
});

module.exports = app;
