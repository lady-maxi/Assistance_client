const express = require('express');
const morgan = require('morgan');
const cors = require('cors');
const { createProxyMiddleware } = require('http-proxy-middleware');

const app = express();
const PORT = process.env.PORT || 8000;

// Middleware dans le bon ordre
app.use(cors());
app.use(express.json({
  limit: '10mb',
  verify: (req, res, buf) => {
    req.rawBody = buf.toString();
    console.log('[API Gateway] Raw body received:', req.rawBody);
  }
}));
app.use(morgan('dev'));

// Configuration des services
const serviceConfig = {
  events: {
    target: process.env.NODE_ENV === 'production' 
      ? 'http://event-service:8080' 
      : 'http://localhost:8080',
    path: '/api/events'
  },
  reservations: {
    target: process.env.NODE_ENV === 'production'
      ? 'http://reservation-service:3000'
      : 'http://localhost:3000',
    path: '/api/reservations'
  },
  notifications: {
    target: process.env.NODE_ENV === 'production'
      ? 'http://notification-service:5100'
      : 'http://localhost:5100',
    path: '/api/notifications'
  }
};

// Middleware de logging amélioré
app.use((req, res, next) => {
  console.log(`[API Gateway] ${req.method} ${req.url}`);
  console.log('Headers:', req.headers);
  if (req.rawBody) {
    console.log('Body size:', Buffer.byteLength(req.rawBody), 'bytes');
  }
  next();
});

// Configuration des proxies
Object.entries(serviceConfig).forEach(([service, config]) => {
  app.use(config.path, createProxyMiddleware({
    target: config.target,
    changeOrigin: true,
    pathRewrite: { [`^${config.path}`]: config.path },
    onProxyReq: (proxyReq, req) => {
      if (req.rawBody) {
        proxyReq.setHeader('Content-Type', 'application/json');
        proxyReq.setHeader('Content-Length', Buffer.byteLength(req.rawBody));
        proxyReq.write(req.rawBody);
      }
    },
    onError: (err, req, res) => {
      console.error(`[API Gateway] Proxy error (${service}):`, err);
      res.status(502).json({ 
        error: 'Bad Gateway',
        service: service,
        message: err.message
      });
    },
    logLevel: 'debug'
  }));
});

// Route d'accueil
app.get('/', (req, res) => {
  res.json({
    message: 'Welcome to the Event Booking API Gateway',
    services: Object.fromEntries(
      Object.entries(serviceConfig).map(([key, val]) => [key, val.path])),
  });
});

// Gestion des erreurs
app.use((err, req, res, next) => {
  console.error('[API Gateway] Error:', err.stack);
  res.status(500).json({
    error: 'Internal Server Error',
    message: err.message,
    timestamp: new Date().toISOString()
  });
});

// Configuration du serveur
const server = app.listen(PORT, () => {
  console.log(`[API Gateway] Running on port ${PORT}`);
});

// Optimisation des timeouts
server.keepAliveTimeout = 60000;
server.headersTimeout = 65000;

module.exports = app;