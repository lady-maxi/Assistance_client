"""
Configuration du Service Paiements - Polyglot Persistence
Démontre l'utilisation combinée de PostgreSQL + Redis

PostgreSQL: Pour les transactions ACID critiques (paiements)
Redis: Pour le cache haute performance et les sessions
"""

import os
import redis
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# Configuration PostgreSQL pour les transactions
POSTGRES_URL = os.getenv(
    'POSTGRES_URL',
    'postgresql://payments_user:payments_password@localhost:5432/payments_db'
)

# Configuration Redis pour le cache
REDIS_URL = os.getenv('REDIS_URL', 'redis://localhost:6379/0')

# SQLAlchemy setup
engine = create_engine(
    POSTGRES_URL,
    pool_size=20,
    max_overflow=30,
    pool_pre_ping=True,
    echo=True if os.getenv('DEBUG') == 'true' else False
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# Redis setup
redis_client = redis.Redis.from_url(
    REDIS_URL,
    decode_responses=True,
    socket_connect_timeout=5,
    socket_timeout=5,
    retry_on_timeout=True
)

# =========================================================================
# TODO-POLY1: Implémentez la classe CacheManager pour gérer le cache Redis
# =========================================================================
class CacheManager:
    def __init__(self, redis_client):
        self.redis = redis_client
        self.logger = logging.getLogger(__name__)

    def get(self, key):
        """Récupère une valeur depuis Redis. Retourne None en cas d'erreur."""
        try:
            cached_data = self.redis.get(key)
            return json.loads(cached_data) if cached_data else None
        except (redis.RedisError, json.JSONDecodeError) as e:
            self.logger.error(f"Redis GET error for key {key}: {str(e)}")
            return None

    def set(self, key, value, ttl=None):
        """Stocke une valeur dans Redis avec un TTL optionnel (en secondes)."""
        try:
            serialized_value = json.dumps(value)
            if ttl:
                self.redis.setex(key, timedelta(seconds=ttl), serialized_value)
            else:
                self.redis.set(key, serialized_value)
            return True
        except (redis.RedisError, TypeError) as e:
            self.logger.error(f"Redis SET error for key {key}: {str(e)}")
            return False

    def delete(self, key):
        """Supprime une clé du cache."""
        try:
            return self.redis.delete(key) > 0
        except redis.RedisError as e:
            self.logger.error(f"Redis DELETE error for key {key}: {str(e)}")
            return False

    def exists(self, key):
        """Vérifie si une clé existe dans le cache."""
        try:
            return self.redis.exists(key)
        except redis.RedisError as e:
            self.logger.error(f"Redis EXISTS error for key {key}: {str(e)}")
            return False

cache_manager = CacheManager(redis_client)
