# Fichier de migration (ex: migrations/versions/xxxx_fix_user_id_type.py)
from alembic import op
import sqlalchemy as sa

def upgrade():
    op.alter_column('payments', 'user_id', type_=sa.String(50))

def downgrade():
    op.alter_column('payments', 'user_id', type_=sa.Numeric())